# bpctl Install
```
pip install bpctl
```
# bpctl custom installation
1 clone package
```
#!/bin/bash
python3 <bpctl-package-path>lib/bpctl/bpctl.py "$@"
```
2 Put this content into `/bin/bpctl`
3 `chmod +x /bin/bpctl`
