import os

def read_current_working_dir():
    pass